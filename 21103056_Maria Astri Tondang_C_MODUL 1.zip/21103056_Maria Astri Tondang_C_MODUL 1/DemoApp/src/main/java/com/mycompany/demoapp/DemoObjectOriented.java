/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.demoapp;

/**
 *
 * @author WIN 11
 * Maria Astri Tondang
 * 21103056
 */
public class DemoObjectOriented {
    public void helloWorld(int jmlh_looping){
        System.out.println("Display Hello World");
        for(int i=0; i<jmlh_looping; i++){
            System.out.println(+(i+1) + ". Hello World");
        }
    }
    
    public int tambah(int bil1, int bil2){
        return(bil1+bil2);
    }
    
}
